export default function StatCard({ label, value, detail, icon: Icon }) {
  return <article className="stat-card">
    <div><span className="stat-label">{label}</span><strong>{value}</strong><small>{detail}</small></div>
    <span className="stat-icon"><Icon size={21} /></span>
  </article>;
}
