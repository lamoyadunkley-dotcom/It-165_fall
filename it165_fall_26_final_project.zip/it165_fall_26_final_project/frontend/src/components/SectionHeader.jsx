export default function SectionHeader({ eyebrow, title, description, action }) {
  return <div className="section-header">
    <div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2><p>{description}</p></div>
    {action}
  </div>;
}
