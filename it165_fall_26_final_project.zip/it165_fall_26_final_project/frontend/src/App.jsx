import { useState } from 'react';
import { LayoutDashboard, Package, ClipboardList, ChefHat, Leaf, Bell, Menu, X, Sparkles } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import Orders from './pages/Orders';
import Recipes from './pages/Recipes';

const nav=[{id:'dashboard',label:'Dashboard',icon:LayoutDashboard},{id:'products',label:'Products',icon:Package},{id:'orders',label:'Orders',icon:ClipboardList},{id:'recipes',label:'Recipe ideas',icon:ChefHat}];
export default function App(){
  const [active,setActive]=useState('dashboard');const [refreshKey,setRefreshKey]=useState(0);const [mobileOpen,setMobileOpen]=useState(false);
  const refresh=()=>setRefreshKey(k=>k+1);
  const select=id=>{setActive(id);setMobileOpen(false);};
  return <div className="app-shell">
    {mobileOpen&&<button className="mobile-scrim" aria-label="Close navigation" onClick={()=>setMobileOpen(false)} />}
    <aside className={`sidebar ${mobileOpen?'sidebar-open':''}`}>
      <div className="brand"><div className="brand-mark"><Leaf size={22}/></div><div><strong>LASLOYALE</strong><span>JUICE & PASTRIES BAR</span></div><button className="close-nav" onClick={()=>setMobileOpen(false)}><X size={19}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(item=>{const Icon=item.icon;return <button key={item.id} className={`nav-link ${active===item.id?'active':''}`} onClick={()=>select(item.id)}><Icon size={18}/>{item.label}{item.id==='orders'&&<span className="nav-dot"/>}</button>;})}</nav>
      <div className="sidebar-bottom"><div className="sidebar-note"><Sparkles size={17}/><strong>Freshness is our signature.</strong><p>Made with care. Served with love.</p></div><div className="user-mini"><div className="avatar">L</div><div><strong>LASLOYALE</strong><span>Business workspace</span></div></div></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="menu-toggle" onClick={()=>setMobileOpen(true)}><Menu size={21}/></button><div className="breadcrumb">Workspace <span>/</span> <strong>{nav.find(n=>n.id===active)?.label}</strong></div><div className="topbar-right"><span className="open-indicator"><i/> Store workspace</span><button className="icon-button notification" aria-label="Notifications"><Bell size={18}/></button></div></header>
      {active==='dashboard'&&<Dashboard refreshKey={refreshKey} goToOrders={()=>select('orders')}/>}
      {active==='products'&&<Products onChanged={refresh}/>}
      {active==='orders'&&<Orders onChanged={refresh}/>}
      {active==='recipes'&&<Recipes/>}
      <footer className="footer">© {new Date().getFullYear()} LASLOYALE Natural Juice and Pastries Bar <span>IT165 Fall 2026 · MERN Stack Project</span></footer>
    </main>
  </div>;
}
