import { useEffect, useState } from 'react';
import { Package, ClipboardList, Clock3, DollarSign, ArrowUpRight } from 'lucide-react';
import { apiRequest } from '../api';
import StatCard from '../components/StatCard';
import SectionHeader from '../components/SectionHeader';

const money = n => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n || 0);
export default function Dashboard({ refreshKey, goToOrders }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    apiRequest('/dashboard').then(setData).catch(e => setError(e.message));
  }, [refreshKey]);
  return <div className="page-content">
    <SectionHeader eyebrow="YOUR BUSINESS AT A GLANCE" title="Good day, LASLOYALE" description="Here is what is happening at your juice and pastries bar." />
    {error && <div className="alert error">{error}. Make sure the backend and MongoDB are running.</div>}
    <div className="stats-grid">
      <StatCard label="Menu products" value={data?.productCount ?? '—'} detail="Products in your menu" icon={Package}/>
      <StatCard label="Total orders" value={data?.orderCount ?? '—'} detail="All recorded orders" icon={ClipboardList}/>
      <StatCard label="Open orders" value={data?.pendingCount ?? '—'} detail="Awaiting completion" icon={Clock3}/>
      <StatCard label="Completed sales" value={money(data?.completedRevenue)} detail="Completed orders only" icon={DollarSign}/>
    </div>
    <section className="panel">
      <div className="panel-heading"><div><span className="eyebrow">LATEST ACTIVITY</span><h3>Recent orders</h3></div><button className="text-button" onClick={goToOrders}>View all <ArrowUpRight size={15}/></button></div>
      {!data && !error ? <p className="muted">Loading business activity…</p> :
        data?.recentOrders?.length ? <div className="table-wrap"><table><thead><tr><th>Customer</th><th>Order date</th><th>Total</th><th>Status</th></tr></thead><tbody>
          {data.recentOrders.map(o => <tr key={o._id}><td className="primary-cell">{o.customerName}</td><td>{new Date(o.createdAt).toLocaleDateString()}</td><td>{money(o.total)}</td><td><span className={`status status-${o.status.toLowerCase()}`}>{o.status}</span></td></tr>)}
        </tbody></table></div> : <div className="empty-state"><ClipboardList size={28}/><strong>No orders yet</strong><span>Your new customer orders will appear here.</span></div>}
    </section>
    <div className="tip-card"><span className="tip-mark">✦</span><div><strong>A little reminder</strong><p>Fresh ingredients, thoughtful service, and a little sweetness make every LASLOYALE order special.</p></div></div>
  </div>;
}
