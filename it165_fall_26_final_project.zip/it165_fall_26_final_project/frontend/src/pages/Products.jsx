import { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, X } from 'lucide-react';
import { apiRequest } from '../api';
import SectionHeader from '../components/SectionHeader';

const blank = { name:'', category:'Juice', description:'', price:'', size:'16 oz', imageUrl:'', available:true };
const money = n => new Intl.NumberFormat('en-US', { style:'currency', currency:'USD' }).format(n || 0);
export default function Products({ onChanged }) {
  const [products,setProducts] = useState([]);
  const [form,setForm] = useState(blank);
  const [editing,setEditing] = useState(null);
  const [showForm,setShowForm] = useState(false);
  const [query,setQuery] = useState('');
  const [category,setCategory] = useState('All');
  const [error,setError] = useState('');
  const [saving,setSaving] = useState(false);
  async function load(){ try { setProducts(await apiRequest('/products')); setError(''); } catch(e){ setError(e.message); } }
  useEffect(()=>{ load(); },[]);
  const visible = products.filter(p => (category==='All'||p.category===category) && `${p.name} ${p.description}`.toLowerCase().includes(query.toLowerCase()));
  function startNew(){ setEditing(null); setForm(blank); setShowForm(true); setError(''); }
  function startEdit(p){ setEditing(p._id); setForm({...p,price:String(p.price)}); setShowForm(true); setError(''); }
  async function save(e){
    e.preventDefault(); setSaving(true); setError('');
    try {
      const body = {...form, price:Number(form.price)};
      await apiRequest(editing ? `/products/${editing}` : '/products',{method:editing?'PUT':'POST',body:JSON.stringify(body)});
      setShowForm(false); setForm(blank); setEditing(null); await load(); onChanged();
    } catch(e){ setError(e.message); } finally { setSaving(false); }
  }
  async function remove(id){
    if(!window.confirm('Delete this product from the menu?')) return;
    try { await apiRequest(`/products/${id}`,{method:'DELETE'}); await load(); onChanged(); }
    catch(e){ setError(e.message); }
  }
  return <div className="page-content">
    <SectionHeader eyebrow="YOUR MENU" title="Products & treats" description="Keep your juice, smoothies, and pastries menu up to date." action={<button className="button button-primary" onClick={startNew}><Plus size={17}/> Add product</button>}/>
    {error && <div className="alert error">{error}</div>}
    <div className="toolbar"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search your menu…"/></div>
      <select value={category} onChange={e=>setCategory(e.target.value)}><option>All</option><option>Juice</option><option>Smoothie</option><option>Pastry</option><option>Other</option></select>
    </div>
    {showForm && <section className="panel form-panel"><div className="panel-heading"><div><span className="eyebrow">{editing?'UPDATE MENU':'NEW MENU ITEM'}</span><h3>{editing?'Edit product':'Add a product'}</h3></div><button className="icon-button" onClick={()=>setShowForm(false)} aria-label="Close"><X size={18}/></button></div>
      <form className="form-grid" onSubmit={save}>
        <label>Product name<input required maxLength="100" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="e.g. Pineapple Ginger Juice"/></label>
        <label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>Juice</option><option>Smoothie</option><option>Pastry</option><option>Other</option></select></label>
        <label>Price (USD)<input required type="number" min="0" step="0.01" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="10.00"/></label>
        <label>Size<input value={form.size} onChange={e=>setForm({...form,size:e.target.value})} placeholder="16 oz"/></label>
        <label className="full-field">Description<textarea rows="2" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe this menu item…"/></label>
        <label className="full-field">Image URL (optional)<input type="url" value={form.imageUrl} onChange={e=>setForm({...form,imageUrl:e.target.value})} placeholder="https://…"/></label>
        <label className="check-label"><input type="checkbox" checked={form.available} onChange={e=>setForm({...form,available:e.target.checked})}/> Available for ordering</label>
        <div className="form-actions"><button type="button" className="button button-light" onClick={()=>setShowForm(false)}>Cancel</button><button className="button button-primary" disabled={saving}>{saving?'Saving…':editing?'Save changes':'Add product'}</button></div>
      </form>
    </section>}
    <div className="product-grid">
      {visible.map(p=><article className="product-card" key={p._id}>
        <div className={`product-art art-${p.category.toLowerCase()}`}>{p.imageUrl?<img src={p.imageUrl} alt={p.name} onError={e=>{e.currentTarget.style.display='none'}}/>:<span>{p.category==='Pastry'?'🧁':p.category==='Smoothie'?'🥭':'🍹'}</span>}<span className="category-chip">{p.category}</span></div>
        <div className="product-info"><div className="product-title-row"><h3>{p.name}</h3><strong>{money(p.price)}</strong></div><p>{p.description||'A LASLOYALE favorite.'}</p><div className="product-meta"><span>{p.size||'Standard size'}</span><span className={p.available?'available':'unavailable'}>{p.available?'Available':'Unavailable'}</span></div>
        <div className="card-actions"><button onClick={()=>startEdit(p)}><Pencil size={14}/> Edit</button><button className="delete-action" onClick={()=>remove(p._id)}><Trash2 size={14}/> Delete</button></div></div>
      </article>)}
    </div>
    {visible.length===0 && <div className="empty-state"><strong>No menu items found</strong><span>Add a product or change your search.</span></div>}
  </div>;
}
