import { useEffect, useState } from 'react';
import { Plus, Trash2, ClipboardList } from 'lucide-react';
import { apiRequest } from '../api';
import SectionHeader from '../components/SectionHeader';

const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n||0);
export default function Orders({ onChanged }) {
  const [orders,setOrders]=useState([]), [products,setProducts]=useState([]);
  const [customerName,setCustomerName]=useState(''), [customerPhone,setCustomerPhone]=useState('');
  const [notes,setNotes]=useState(''), [lines,setLines]=useState([{productId:'',quantity:1}]);
  const [showForm,setShowForm]=useState(false), [error,setError]=useState(''), [saving,setSaving]=useState(false);
  async function load(){ try { const [o,p]=await Promise.all([apiRequest('/orders'),apiRequest('/products?available=true')]); setOrders(o); setProducts(p); setError(''); } catch(e){setError(e.message);} }
  useEffect(()=>{load();},[]);
  function addLine(){setLines([...lines,{productId:'',quantity:1}]);}
  function updateLine(i,key,value){setLines(lines.map((line,index)=>index===i?{...line,[key]:value}:line));}
  const estimate=lines.reduce((sum,l)=>sum+(products.find(p=>p._id===l.productId)?.price||0)*(Number(l.quantity)||0),0);
  async function create(e){
    e.preventDefault();setSaving(true);setError('');
    try {
      await apiRequest('/orders',{method:'POST',body:JSON.stringify({customerName,customerPhone,notes,items:lines.filter(l=>l.productId).map(l=>({productId:l.productId,quantity:Number(l.quantity)}))})});
      setCustomerName('');setCustomerPhone('');setNotes('');setLines([{productId:'',quantity:1}]);setShowForm(false);await load();onChanged();
    }catch(e){setError(e.message);}finally{setSaving(false);}
  }
  async function changeStatus(id,status){
    try{await apiRequest(`/orders/${id}/status`,{method:'PATCH',body:JSON.stringify({status})});await load();onChanged();}
    catch(e){setError(e.message);}
  }
  async function remove(id){
    if(!window.confirm('Delete this order?'))return;
    try{await apiRequest(`/orders/${id}`,{method:'DELETE'});await load();onChanged();}
    catch(e){setError(e.message);}
  }
  return <div className="page-content">
    <SectionHeader eyebrow="CUSTOMER SERVICE" title="Orders" description="Create customer orders and follow each one from preparation to pickup." action={<button className="button button-primary" onClick={()=>setShowForm(!showForm)}><Plus size={17}/> New order</button>}/>
    {error&&<div className="alert error">{error}</div>}
    {showForm&&<section className="panel form-panel"><div className="panel-heading"><div><span className="eyebrow">NEW CUSTOMER ORDER</span><h3>Order details</h3></div></div>
      <form onSubmit={create} className="form-grid">
        <label>Customer name<input required value={customerName} onChange={e=>setCustomerName(e.target.value)} placeholder="Customer name"/></label>
        <label>Phone number (optional)<input value={customerPhone} onChange={e=>setCustomerPhone(e.target.value)} placeholder="Phone number"/></label>
        <div className="full-field order-lines"><div className="line-heading"><strong>Order items</strong><button type="button" className="text-button" onClick={addLine}><Plus size={14}/> Add item</button></div>
          {lines.map((line,i)=><div className="order-line" key={i}><select required value={line.productId} onChange={e=>updateLine(i,'productId',e.target.value)}><option value="">Choose a product</option>{products.map(p=><option key={p._id} value={p._id}>{p.name} — {money(p.price)}</option>)}</select><input aria-label="Quantity" type="number" min="1" step="1" value={line.quantity} onChange={e=>updateLine(i,'quantity',e.target.value)}/>{lines.length>1&&<button type="button" className="icon-button" onClick={()=>setLines(lines.filter((_,idx)=>idx!==i))}>×</button>}</div>)}
          <div className="estimate">Estimated total <strong>{money(estimate)}</strong><small>Final total is calculated securely by the backend using current menu prices.</small></div>
        </div>
        <label className="full-field">Order notes<textarea rows="2" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Special instructions…"/></label>
        <div className="form-actions"><button type="button" className="button button-light" onClick={()=>setShowForm(false)}>Cancel</button><button className="button button-primary" disabled={saving}>{saving?'Saving…':'Place order'}</button></div>
      </form>
    </section>}
    <section className="panel"><div className="panel-heading"><div><span className="eyebrow">ORDER HISTORY</span><h3>All orders <span className="count-pill">{orders.length}</span></h3></div></div>
      {orders.length===0?<div className="empty-state"><ClipboardList size={28}/><strong>No orders recorded</strong><span>Create your first customer order to see it here.</span></div>:
      <div className="table-wrap"><table><thead><tr><th>Customer</th><th>Items</th><th>Total</th><th>Order status</th><th>Date</th><th></th></tr></thead><tbody>
        {orders.map(o=><tr key={o._id}><td className="primary-cell">{o.customerName}<small className="table-sub">{o.customerPhone}</small></td><td>{o.items.map(i=>`${i.quantity} × ${i.name}`).join(', ')}</td><td>{money(o.total)}</td><td><select className={`status-select status-${o.status.toLowerCase()}`} value={o.status} onChange={e=>changeStatus(o._id,e.target.value)}>{['Pending','Preparing','Ready','Completed'].map(s=><option key={s}>{s}</option>)}</select></td><td>{new Date(o.createdAt).toLocaleDateString()}</td><td><button className="icon-button danger-icon" onClick={()=>remove(o._id)} aria-label="Delete order"><Trash2 size={15}/></button></td></tr>)}
      </tbody></table></div>}
    </section>
  </div>;
}
