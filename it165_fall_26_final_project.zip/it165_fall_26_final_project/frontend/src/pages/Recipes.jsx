import { useState } from 'react';
import { Search, ExternalLink, ChefHat } from 'lucide-react';
import { apiRequest } from '../api';
import SectionHeader from '../components/SectionHeader';

export default function Recipes(){
  const [query,setQuery]=useState('');const [recipes,setRecipes]=useState([]);const [loading,setLoading]=useState(false);const [error,setError]=useState('');const [searched,setSearched]=useState(false);
  async function search(e){e.preventDefault();if(!query.trim())return;setLoading(true);setError('');setSearched(true);
    try{const data=await apiRequest(`/recipes/search?query=${encodeURIComponent(query.trim())}`);setRecipes(data.results);}
    catch(e){setError(e.message);setRecipes([]);}finally{setLoading(false);}
  }
  return <div className="page-content">
    <SectionHeader eyebrow="A LITTLE INSPIRATION" title="Recipe ideas" description="Explore recipes from a free public recipe service. Use these ideas to inspire your next menu special."/>
    <section className="recipe-search panel"><div className="recipe-icon"><ChefHat size={25}/></div><h3>What would you like to make?</h3><p>Search by ingredient or recipe name to discover meal ideas.</p>
      <form onSubmit={search} className="recipe-form"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Try chicken, cake, salmon…" /></div><button className="button button-primary" disabled={loading||!query.trim()}>{loading?'Searching…':'Search recipes'}</button></form>
      <small>Powered by TheMealDB public API. Recipe content and images belong to their respective sources.</small>
    </section>
    {error&&<div className="alert error">{error}</div>}
    {loading&&<p className="muted">Finding recipe ideas…</p>}
    {!loading&&searched&&recipes.length===0&&!error&&<div className="empty-state"><strong>No recipes found</strong><span>Try another search term.</span></div>}
    <div className="recipe-grid">{recipes.map(r=><article className="recipe-card" key={r.id}><img src={r.image} alt={r.name}/><div className="recipe-info"><span className="eyebrow">{[r.area,r.category].filter(Boolean).join(' · ')}</span><h3>{r.name}</h3><p>{(r.instructions||'').slice(0,145)}{r.instructions?.length>145?'…':''}</p><div className="recipe-links">{r.source&&<a href={r.source} target="_blank" rel="noreferrer">Recipe source <ExternalLink size={13}/></a>}{r.youtube&&<a href={r.youtube} target="_blank" rel="noreferrer">Video <ExternalLink size={13}/></a>}</div></div></article>)}</div>
  </div>;
}
