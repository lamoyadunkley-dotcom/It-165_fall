import express from 'express';

const router = express.Router();

// Server-side proxy keeps the external API integration in one place and
// gives the React client a consistent error response.
router.get('/search', async (req, res, next) => {
  try {
    const query = String(req.query.query || '').trim();
    if (!query) return res.status(400).json({ error: 'Enter a recipe search term.' });
    if (query.length > 80) return res.status(400).json({ error: 'Search term is too long.' });

    const response = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(query)}`);
    if (!response.ok) return res.status(502).json({ error: 'The recipe service is temporarily unavailable.' });
    const data = await response.json();
    const meals = (data.meals || []).map(meal => ({
      id: meal.idMeal,
      name: meal.strMeal,
      category: meal.strCategory,
      area: meal.strArea,
      instructions: meal.strInstructions,
      image: meal.strMealThumb,
      source: meal.strSource,
      youtube: meal.strYoutube
    }));
    res.json({ results: meals });
  } catch (err) {
    res.status(502);
    next(new Error('Could not reach TheMealDB. Please try again later.'));
  }
});

export default router;
