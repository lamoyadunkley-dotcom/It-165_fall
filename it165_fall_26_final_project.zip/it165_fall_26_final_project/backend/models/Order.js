import mongoose from 'mongoose';

const orderItemSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  name: { type: String, required: true },
  quantity: { type: Number, required: true, min: 1 },
  unitPrice: { type: Number, required: true, min: 0 }
}, { _id: false });

const orderSchema = new mongoose.Schema({
  customerName: { type: String, required: [true, 'Customer name is required'], trim: true, maxlength: 100 },
  customerPhone: { type: String, trim: true, default: '' },
  items: { type: [orderItemSchema], validate: v => v.length > 0 },
  total: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ['Pending', 'Preparing', 'Ready', 'Completed'], default: 'Pending' },
  notes: { type: String, trim: true, maxlength: 500, default: '' }
}, { timestamps: true });

export default mongoose.model('Order', orderSchema);
