import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: { type: String, required: [true, 'Product name is required'], trim: true, maxlength: 100 },
  category: { type: String, enum: ['Juice', 'Smoothie', 'Pastry', 'Other'], required: true },
  description: { type: String, trim: true, maxlength: 500, default: '' },
  price: { type: Number, required: true, min: [0, 'Price cannot be negative'] },
  size: { type: String, trim: true, default: 'N/A' },
  imageUrl: { type: String, trim: true, default: '' },
  available: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model('Product', productSchema);
